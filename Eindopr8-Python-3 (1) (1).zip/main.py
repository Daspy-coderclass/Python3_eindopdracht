from rich.table import Table
from rich.prompt import Prompt
from rich.console import Console
console = Console()

import os
clear = lambda : os.system('cls')
def clear():
  os.system( 'clear' )


def print_Tabel():
  table = Table(show_header=True, header_style="bold magenta",show_footer=True,footer_style="bold blue")
  table.add_column("MENU", justify="right", style="bright_yellow", no_wrap=True)
  table.add_column("Contactenlijst", )
  table.add_column("",justify="right", style="bright_yellow", no_wrap=True)
  table.add_column("")
 
  table.add_row("1", "Bekijken", "2", "Toevoegen")
  table.add_row("3", "Aanpassen", "4", "Verwijderen")
  table.add_row("5", "Opslaan", "6", "Afsluiten")
  console.print(table)

def contacten_ophalen():
  Contacts = {}
  with open("Contacts.txt") as c_list:
    for line in c_list:
      (key, val) = line.split()
      Contacts[str(key)] = val
  return Contacts

def check_geldigheid(name, Contacts):
  ongeldig = True
  while ongeldig:
    if name not in Contacts:
      name = input("Geef een geldig contact ").lower()
    else:
      ongeldig = False
  return name
    

def bekijk_contacten(Contacts):
  console.print("[bold red]Aantal contacten: ",str(len(Contacts)),"\n")
  for key in Contacts:
    print((key), Contacts[key])

def save_contacten(Contacts):
  print("Bezig om contacten te sychroniseren met lokale bestanden..")
  with open("Contacts.txt", "w") as c_list:
    c_list.write("")
  for key, value in Contacts.items():
    NewData = ((key) +' '+ value +'\n')
    with open("Contacts.txt", "a") as c_list:
      c_list.write(NewData)
  print('Contacten zijn gesychroniseerd')

def add_contacten(Contacts):
  bekijk_contacten(Contacts)
  name = input("\nNieuw contact naam: ").lower()
  if name in Contacts:
    print("!!!Dit contact bestaat al")
    keuze = Prompt.ask("wil je het contact alsnog aanpassen?", choices=["j", "n"])
    if keuze == "n":
      return
  nummer = input("Telefoon nummer: ")
  Contacts[name] = nummer

def change_contacten(Contacts):
  bekijk_contacten(Contacts)
  name = input("\nWelk contact wil je aanpassen?: ").lower()
  name = check_geldigheid(name, Contacts)
  print("Huidige naam:", name)
  Newname = input("Nieuwe naam: ")
  print("Huidig nummer: " + Contacts[name])
  nummer = input("Nieuw nummer: ")
  Contacts[name] = nummer
  Contacts[Newname] = Contacts.pop(name)
  return Contacts

def verwijder_contacten(Contacts):
  bekijk_contacten(Contacts)
  name = input("\nWelk contact wil je verwijderen? ").lower()
  name = check_geldigheid(name, Contacts)
  check = Prompt.ask("Weet je zeker dat je dat contact wilt verwijderen?", choices=["j", "n"])
  if check == 'j':
    del Contacts[name]

def Keuze_verwerken(keuze, Contacts):
  if keuze == '1':
    bekijk_contacten(Contacts)
  elif keuze == '2':
    add_contacten(Contacts)
  elif keuze == '3':
    change_contacten(Contacts)
  elif keuze == '4':
    verwijder_contacten(Contacts)
  elif keuze == '5':
    save_contacten(Contacts)
  elif keuze == '6':
    exit()
  return Contacts


def begin_van_loop():
  print()
  input("Druk op ENTER om verder te gaan..")
  clear()
def keuze_vragen():
  keuze = Prompt.ask("Keuze", choices=["1", "2", "3", "4", "5", "6"])
  return keuze

def main():
  running = True
  Contacts = contacten_ophalen()
  while running:
    begin_van_loop()
    print_Tabel()
    keuze = keuze_vragen()
    clear()
    Contacts = Keuze_verwerken(keuze, Contacts)

main()